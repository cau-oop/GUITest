/********************************************************************************
** Form generated from reading UI file 'loginfail.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINFAIL_H
#define UI_LOGINFAIL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_LoginFail
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;

    void setupUi(QDialog *LoginFail)
    {
        if (LoginFail->objectName().isEmpty())
            LoginFail->setObjectName(QStringLiteral("LoginFail"));
        LoginFail->resize(350, 350);
        label = new QLabel(LoginFail);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(70, 10, 301, 111));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setTextFormat(Qt::AutoText);
        pushButton = new QPushButton(LoginFail);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(130, 260, 75, 30));
        label_2 = new QLabel(LoginFail);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 100, 231, 141));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        label_2->setFont(font1);

        retranslateUi(LoginFail);

        QMetaObject::connectSlotsByName(LoginFail);
    } // setupUi

    void retranslateUi(QDialog *LoginFail)
    {
        LoginFail->setWindowTitle(QApplication::translate("LoginFail", "Dialog", nullptr));
        label->setText(QApplication::translate("LoginFail", "\353\241\234\352\267\270\354\235\270\354\227\220 \354\213\244\355\214\250\355\226\210\354\212\265\353\213\210\353\213\244.", nullptr));
        pushButton->setText(QApplication::translate("LoginFail", "\355\231\225\354\235\270", nullptr));
        label_2->setText(QApplication::translate("LoginFail", "<html><head/><body><p align=\"center\">\354\225\204\354\235\264\353\224\224\353\245\274 </p><p align=\"center\">\354\236\230\353\252\273 \354\236\205\353\240\245\355\225\230\354\205\250\354\212\265\353\213\210\353\213\244.</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginFail: public Ui_LoginFail {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINFAIL_H
