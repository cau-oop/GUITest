/********************************************************************************
** Form generated from reading UI file 'memberfail2.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEMBERFAIL2_H
#define UI_MEMBERFAIL2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_MemberFail2
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;

    void setupUi(QDialog *MemberFail2)
    {
        if (MemberFail2->objectName().isEmpty())
            MemberFail2->setObjectName(QStringLiteral("MemberFail2"));
        MemberFail2->resize(350, 350);
        label = new QLabel(MemberFail2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 20, 301, 111));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setTextFormat(Qt::AutoText);
        pushButton = new QPushButton(MemberFail2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(130, 270, 75, 30));
        label_2 = new QLabel(MemberFail2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 110, 231, 141));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        label_2->setFont(font1);

        retranslateUi(MemberFail2);

        QMetaObject::connectSlotsByName(MemberFail2);
    } // setupUi

    void retranslateUi(QDialog *MemberFail2)
    {
        MemberFail2->setWindowTitle(QApplication::translate("MemberFail2", "Dialog", nullptr));
        label->setText(QApplication::translate("MemberFail2", "\355\232\214\354\233\220\352\260\200\354\236\205\354\227\220 \354\213\244\355\214\250\355\226\210\354\212\265\353\213\210\353\213\244.", nullptr));
        pushButton->setText(QApplication::translate("MemberFail2", "\355\231\225\354\235\270", nullptr));
        label_2->setText(QApplication::translate("MemberFail2", "<html><head/><body><p align=\"center\">\355\225\204\354\210\230 \354\236\205\353\240\245 \354\232\224\354\206\214\353\245\274</p><p align=\"center\">\353\252\250\353\221\220 \354\236\205\353\240\245\355\225\230\354\247\200 \354\225\212\354\225\230\354\212\265\353\213\210\353\213\244.</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MemberFail2: public Ui_MemberFail2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEMBERFAIL2_H
