/********************************************************************************
** Form generated from reading UI file 'memberfail.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEMBERFAIL_H
#define UI_MEMBERFAIL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_MemberFail
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;

    void setupUi(QDialog *MemberFail)
    {
        if (MemberFail->objectName().isEmpty())
            MemberFail->setObjectName(QStringLiteral("MemberFail"));
        MemberFail->resize(350, 350);
        label = new QLabel(MemberFail);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 30, 301, 111));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setTextFormat(Qt::AutoText);
        pushButton = new QPushButton(MemberFail);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(130, 280, 75, 30));
        label_2 = new QLabel(MemberFail);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 120, 231, 141));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        label_2->setFont(font1);

        retranslateUi(MemberFail);

        QMetaObject::connectSlotsByName(MemberFail);
    } // setupUi

    void retranslateUi(QDialog *MemberFail)
    {
        MemberFail->setWindowTitle(QApplication::translate("MemberFail", "Dialog", nullptr));
        label->setText(QApplication::translate("MemberFail", "\355\232\214\354\233\220\352\260\200\354\236\205\354\227\220 \354\213\244\355\214\250\355\226\210\354\212\265\353\213\210\353\213\244.", nullptr));
        pushButton->setText(QApplication::translate("MemberFail", "\355\231\225\354\235\270", nullptr));
        label_2->setText(QApplication::translate("MemberFail", "<html><head/><body><p align=\"center\">\355\225\264\353\213\271 \354\225\204\354\235\264\353\224\224\353\212\224 \354\235\264\353\257\270 </p><p align=\"center\">\354\241\264\354\236\254\355\225\230\353\212\224 \354\225\204\354\235\264\353\224\224\354\236\205\353\213\210\353\213\244.</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MemberFail: public Ui_MemberFail {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEMBERFAIL_H
