/********************************************************************************
** Form generated from reading UI file 'guestmypage.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUESTMYPAGE_H
#define UI_GUESTMYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GuestMyPage
{
public:
    QPushButton *pushButton_6;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;

    void setupUi(QDialog *GuestMyPage)
    {
        if (GuestMyPage->objectName().isEmpty())
            GuestMyPage->setObjectName(QStringLiteral("GuestMyPage"));
        GuestMyPage->resize(640, 640);
        pushButton_6 = new QPushButton(GuestMyPage);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(20, 20, 91, 61));
        layoutWidget = new QWidget(GuestMyPage);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(210, 60, 201, 271));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(layoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(layoutWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);


        retranslateUi(GuestMyPage);

        QMetaObject::connectSlotsByName(GuestMyPage);
    } // setupUi

    void retranslateUi(QDialog *GuestMyPage)
    {
        GuestMyPage->setWindowTitle(QApplication::translate("GuestMyPage", "Dialog", nullptr));
        pushButton_6->setText(QApplication::translate("GuestMyPage", "\353\222\244\353\241\234", nullptr));
        pushButton->setText(QApplication::translate("GuestMyPage", "\355\232\214\354\233\220\354\240\225\353\263\264 \354\210\230\354\240\225", nullptr));
        pushButton_2->setText(QApplication::translate("GuestMyPage", "\355\214\250\355\202\244\354\247\200 \355\217\211\352\260\200", nullptr));
        pushButton_3->setText(QApplication::translate("GuestMyPage", "\352\260\200\354\235\264\353\223\234 \355\217\211\352\260\200", nullptr));
        pushButton_4->setText(QApplication::translate("GuestMyPage", "\355\214\250\355\202\244\354\247\200 \353\246\254\353\267\260", nullptr));
        pushButton_5->setText(QApplication::translate("GuestMyPage", "\353\241\234\352\267\270\354\225\204\354\233\203", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GuestMyPage: public Ui_GuestMyPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUESTMYPAGE_H
