/********************************************************************************
** Form generated from reading UI file 'passwordcheck.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PASSWORDCHECK_H
#define UI_PASSWORDCHECK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PasswordCheck
{
public:
    QPushButton *pushButton_2;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QDialog *PasswordCheck)
    {
        if (PasswordCheck->objectName().isEmpty())
            PasswordCheck->setObjectName(QStringLiteral("PasswordCheck"));
        PasswordCheck->resize(640, 640);
        pushButton_2 = new QPushButton(PasswordCheck);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 32, 75, 31));
        layoutWidget = new QWidget(PasswordCheck);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(140, 170, 351, 70));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout->addWidget(lineEdit);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);


        retranslateUi(PasswordCheck);

        QMetaObject::connectSlotsByName(PasswordCheck);
    } // setupUi

    void retranslateUi(QDialog *PasswordCheck)
    {
        PasswordCheck->setWindowTitle(QApplication::translate("PasswordCheck", "Dialog", nullptr));
        pushButton_2->setText(QApplication::translate("PasswordCheck", "\353\222\244\353\241\234", nullptr));
        label_2->setText(QApplication::translate("PasswordCheck", "\352\270\260\354\241\264 \353\271\204\353\260\200\353\262\210\355\230\270", nullptr));
        pushButton->setText(QApplication::translate("PasswordCheck", "\355\231\225\354\235\270", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class PasswordCheck: public Ui_PasswordCheck {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PASSWORDCHECK_H
