/********************************************************************************
** Form generated from reading UI file 'adtopay.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADTOPAY_H
#define UI_ADTOPAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_adtopay
{
public:
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QWidget *widget;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_3;

    void setupUi(QDialog *adtopay)
    {
        if (adtopay->objectName().isEmpty())
            adtopay->setObjectName(QStringLiteral("adtopay"));
        adtopay->resize(640, 640);
        label = new QLabel(adtopay);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(300, 30, 54, 12));
        label_2 = new QLabel(adtopay);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 80, 401, 241));
        pushButton = new QPushButton(adtopay);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(490, 170, 80, 20));
        widget = new QWidget(adtopay);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(180, 180, 241, 201));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 160, 75, 23));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(140, 160, 75, 23));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 50, 161, 71));

        retranslateUi(adtopay);
        QObject::connect(pushButton, SIGNAL(clicked()), widget, SLOT(show()));

        QMetaObject::connectSlotsByName(adtopay);
    } // setupUi

    void retranslateUi(QDialog *adtopay)
    {
        adtopay->setWindowTitle(QApplication::translate("adtopay", "Dialog", nullptr));
        label->setText(QApplication::translate("adtopay", "\352\262\260\354\240\234\354\260\275", nullptr));
        label_2->setText(QString());
        pushButton->setText(QApplication::translate("adtopay", "\352\265\254\353\247\244", nullptr));
        pushButton_2->setText(QApplication::translate("adtopay", "\354\230\210", nullptr));
        pushButton_3->setText(QApplication::translate("adtopay", "\354\225\204\353\213\210\354\230\244", nullptr));
        label_3->setText(QApplication::translate("adtopay", "\354\240\225\353\247\220 \352\262\260\354\240\234\355\225\230\354\213\234\352\262\240\354\212\265\353\213\210\352\271\214?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class adtopay: public Ui_adtopay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADTOPAY_H
