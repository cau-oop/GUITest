/********************************************************************************
** Form generated from reading UI file 'newspam.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWSPAM_H
#define UI_NEWSPAM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NewSpam
{
public:
    QPushButton *pushButton;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QLabel *label_2;

    void setupUi(QDialog *NewSpam)
    {
        if (NewSpam->objectName().isEmpty())
            NewSpam->setObjectName(QStringLiteral("NewSpam"));
        NewSpam->resize(640, 640);
        pushButton = new QPushButton(NewSpam);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(304, 300, 81, 31));
        layoutWidget = new QWidget(NewSpam);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(150, 230, 231, 62));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        radioButton = new QRadioButton(layoutWidget);
        radioButton->setObjectName(QStringLiteral("radioButton"));

        horizontalLayout->addWidget(radioButton);

        radioButton_2 = new QRadioButton(layoutWidget);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));

        horizontalLayout->addWidget(radioButton_2);


        verticalLayout->addLayout(horizontalLayout);

        label_2 = new QLabel(NewSpam);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(140, 300, 151, 16));

        retranslateUi(NewSpam);

        QMetaObject::connectSlotsByName(NewSpam);
    } // setupUi

    void retranslateUi(QDialog *NewSpam)
    {
        NewSpam->setWindowTitle(QApplication::translate("NewSpam", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("NewSpam", "\355\231\225\354\235\270", nullptr));
        label->setText(QApplication::translate("NewSpam", "\354\212\244\355\214\270 \353\217\231\354\235\230", nullptr));
        radioButton->setText(QApplication::translate("NewSpam", "O", nullptr));
        radioButton_2->setText(QApplication::translate("NewSpam", "X", nullptr));
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class NewSpam: public Ui_NewSpam {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWSPAM_H
