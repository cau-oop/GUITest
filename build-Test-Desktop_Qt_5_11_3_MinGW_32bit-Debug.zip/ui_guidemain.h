/********************************************************************************
** Form generated from reading UI file 'guidemain.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUIDEMAIN_H
#define UI_GUIDEMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GuideMain
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *GuideMain)
    {
        if (GuideMain->objectName().isEmpty())
            GuideMain->setObjectName(QStringLiteral("GuideMain"));
        GuideMain->resize(640, 640);
        widget = new QWidget(GuideMain);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(190, 160, 291, 291));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);


        retranslateUi(GuideMain);

        QMetaObject::connectSlotsByName(GuideMain);
    } // setupUi

    void retranslateUi(QDialog *GuideMain)
    {
        GuideMain->setWindowTitle(QApplication::translate("GuideMain", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("GuideMain", "\355\232\214\354\233\220 \354\240\225\353\263\264 \354\210\230\354\240\225", nullptr));
        pushButton_2->setText(QApplication::translate("GuideMain", "\354\261\204\355\214\205", nullptr));
        pushButton_3->setText(QApplication::translate("GuideMain", "\353\241\234\352\267\270\354\225\204\354\233\203", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GuideMain: public Ui_GuideMain {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUIDEMAIN_H
