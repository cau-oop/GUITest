/********************************************************************************
** Form generated from reading UI file 'pay.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAY_H
#define UI_PAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Pay
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;

    void setupUi(QDialog *Pay)
    {
        if (Pay->objectName().isEmpty())
            Pay->setObjectName(QStringLiteral("Pay"));
        Pay->resize(350, 350);
        Pay->setAutoFillBackground(false);
        pushButton = new QPushButton(Pay);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(50, 200, 75, 23));
        pushButton_2 = new QPushButton(Pay);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(210, 200, 75, 23));
        label = new QLabel(Pay);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(110, 90, 181, 81));

        retranslateUi(Pay);

        QMetaObject::connectSlotsByName(Pay);
    } // setupUi

    void retranslateUi(QDialog *Pay)
    {
        Pay->setWindowTitle(QApplication::translate("Pay", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("Pay", "\354\230\210", nullptr));
        pushButton_2->setText(QApplication::translate("Pay", "\354\225\204\353\213\210\354\230\244", nullptr));
        label->setText(QApplication::translate("Pay", "\354\240\225\353\247\220 \352\262\260\354\240\234\355\225\230\354\213\234\352\262\240\354\212\265\353\213\210\352\271\214?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Pay: public Ui_Pay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAY_H
