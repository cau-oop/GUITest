/********************************************************************************
** Form generated from reading UI file 'makenew.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAKENEW_H
#define UI_MAKENEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MakeNew
{
public:
    QPushButton *pushButton_4;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *MakeNew)
    {
        if (MakeNew->objectName().isEmpty())
            MakeNew->setObjectName(QStringLiteral("MakeNew"));
        MakeNew->resize(640, 640);
        pushButton_4 = new QPushButton(MakeNew);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(30, 50, 81, 41));
        layoutWidget = new QWidget(MakeNew);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(200, 170, 210, 151));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);


        retranslateUi(MakeNew);

        QMetaObject::connectSlotsByName(MakeNew);
    } // setupUi

    void retranslateUi(QDialog *MakeNew)
    {
        MakeNew->setWindowTitle(QApplication::translate("MakeNew", "Dialog", nullptr));
        pushButton_4->setText(QApplication::translate("MakeNew", "\353\222\244\353\241\234", nullptr));
        pushButton->setText(QApplication::translate("MakeNew", "\354\227\254\355\226\211\354\236\220\353\241\234 \355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
        pushButton_2->setText(QApplication::translate("MakeNew", "\354\202\254\354\227\205\354\236\220\353\241\234 \355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
        pushButton_3->setText(QApplication::translate("MakeNew", "\352\260\200\354\235\264\353\223\234\353\241\234 \355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MakeNew: public Ui_MakeNew {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAKENEW_H
