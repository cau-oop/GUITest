/********************************************************************************
** Form generated from reading UI file 'guestmain.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUESTMAIN_H
#define UI_GUESTMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GuestMain
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label;
    QLabel *label_2;
    QWidget *widget;
    QLabel *ad_pic;
    QPushButton *adbut;

    void setupUi(QDialog *GuestMain)
    {
        if (GuestMain->objectName().isEmpty())
            GuestMain->setObjectName(QStringLiteral("GuestMain"));
        GuestMain->resize(640, 640);
        pushButton = new QPushButton(GuestMain);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(20, 230, 151, 61));
        pushButton_2 = new QPushButton(GuestMain);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 110, 101, 51));
        pushButton_3 = new QPushButton(GuestMain);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 360, 141, 51));
        label = new QLabel(GuestMain);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 20, 151, 51));
        label_2 = new QLabel(GuestMain);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(120, 20, 81, 16));
        widget = new QWidget(GuestMain);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(190, 80, 351, 301));
        ad_pic = new QLabel(widget);
        ad_pic->setObjectName(QStringLiteral("ad_pic"));
        ad_pic->setGeometry(QRect(250, 210, 91, 81));
        adbut = new QPushButton(widget);
        adbut->setObjectName(QStringLiteral("adbut"));
        adbut->setGeometry(QRect(30, 10, 301, 181));

        retranslateUi(GuestMain);

        QMetaObject::connectSlotsByName(GuestMain);
    } // setupUi

    void retranslateUi(QDialog *GuestMain)
    {
        GuestMain->setWindowTitle(QApplication::translate("GuestMain", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("GuestMain", "\353\247\210\354\235\264\355\216\230\354\235\264\354\247\200", nullptr));
        pushButton_2->setText(QApplication::translate("GuestMain", "\352\262\200\354\203\211", nullptr));
        pushButton_3->setText(QApplication::translate("GuestMain", "\354\261\204\355\214\205", nullptr));
        label->setText(QApplication::translate("GuestMain", "\353\241\234\352\267\270\354\235\270 \354\240\225\353\263\264:", nullptr));
        label_2->setText(QString());
        ad_pic->setText(QString());
        adbut->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class GuestMain: public Ui_GuestMain {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUESTMAIN_H
