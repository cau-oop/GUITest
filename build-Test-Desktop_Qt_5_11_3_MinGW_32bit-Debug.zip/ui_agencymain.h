/********************************************************************************
** Form generated from reading UI file 'agencymain.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AGENCYMAIN_H
#define UI_AGENCYMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AgencyMain
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QDialog *AgencyMain)
    {
        if (AgencyMain->objectName().isEmpty())
            AgencyMain->setObjectName(QStringLiteral("AgencyMain"));
        AgencyMain->resize(640, 640);
        widget = new QWidget(AgencyMain);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(200, 140, 231, 271));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);


        retranslateUi(AgencyMain);

        QMetaObject::connectSlotsByName(AgencyMain);
    } // setupUi

    void retranslateUi(QDialog *AgencyMain)
    {
        AgencyMain->setWindowTitle(QApplication::translate("AgencyMain", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("AgencyMain", "\355\232\214\354\233\220 \354\240\225\353\263\264 \354\210\230\354\240\225", nullptr));
        pushButton_2->setText(QApplication::translate("AgencyMain", "\355\214\250\355\202\244\354\247\200 \354\266\224\352\260\200", nullptr));
        pushButton_3->setText(QApplication::translate("AgencyMain", "\355\214\250\355\202\244\354\247\200 \352\264\200\353\246\254", nullptr));
        pushButton_4->setText(QApplication::translate("AgencyMain", "\353\241\234\352\267\270\354\225\204\354\233\203", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AgencyMain: public Ui_AgencyMain {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AGENCYMAIN_H
