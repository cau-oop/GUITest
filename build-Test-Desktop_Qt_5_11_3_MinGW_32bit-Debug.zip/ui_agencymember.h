/********************************************************************************
** Form generated from reading UI file 'agencymember.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AGENCYMEMBER_H
#define UI_AGENCYMEMBER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AgencyMember
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_9;
    QPushButton *pushButton;

    void setupUi(QDialog *AgencyMember)
    {
        if (AgencyMember->objectName().isEmpty())
            AgencyMember->setObjectName(QStringLiteral("AgencyMember"));
        AgencyMember->resize(640, 640);
        widget = new QWidget(AgencyMember);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(80, 70, 471, 511));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(widget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_5);

        label_6 = new QLabel(widget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(widget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_7);

        label_8 = new QLabel(widget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_8);

        label_9 = new QLabel(widget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_9);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        verticalLayout_2->addWidget(lineEdit);

        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        verticalLayout_2->addWidget(lineEdit_2);

        lineEdit_3 = new QLineEdit(widget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        verticalLayout_2->addWidget(lineEdit_3);

        lineEdit_4 = new QLineEdit(widget);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        verticalLayout_2->addWidget(lineEdit_4);

        lineEdit_5 = new QLineEdit(widget);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));

        verticalLayout_2->addWidget(lineEdit_5);

        lineEdit_6 = new QLineEdit(widget);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));

        verticalLayout_2->addWidget(lineEdit_6);

        lineEdit_7 = new QLineEdit(widget);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));

        verticalLayout_2->addWidget(lineEdit_7);

        lineEdit_9 = new QLineEdit(widget);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));

        verticalLayout_2->addWidget(lineEdit_9);


        horizontalLayout->addLayout(verticalLayout_2);


        verticalLayout_3->addLayout(horizontalLayout);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton->setFont(font1);

        verticalLayout_3->addWidget(pushButton);


        retranslateUi(AgencyMember);

        QMetaObject::connectSlotsByName(AgencyMember);
    } // setupUi

    void retranslateUi(QDialog *AgencyMember)
    {
        AgencyMember->setWindowTitle(QApplication::translate("AgencyMember", "Dialog", nullptr));
        label->setText(QApplication::translate("AgencyMember", "1\354\235\270 \354\227\254\355\226\211\354\202\254 \355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
        label_2->setText(QApplication::translate("AgencyMember", "\354\225\204\354\235\264\353\224\224", nullptr));
        label_3->setText(QApplication::translate("AgencyMember", "\353\271\204\353\260\200\353\262\210\355\230\270", nullptr));
        label_4->setText(QApplication::translate("AgencyMember", "\354\202\254\354\227\205\354\236\220 \354\235\264\353\246\204", nullptr));
        label_5->setText(QApplication::translate("AgencyMember", "\354\227\254\355\226\211\354\202\254 \354\235\264\353\246\204", nullptr));
        label_6->setText(QApplication::translate("AgencyMember", "\354\240\204\355\231\224\353\262\210\355\230\270", nullptr));
        label_7->setText(QApplication::translate("AgencyMember", "\354\227\254\355\226\211\354\202\254 \354\202\254\354\227\205\354\236\220 \353\223\261\353\241\235\353\262\210\355\230\270", nullptr));
        label_8->setText(QApplication::translate("AgencyMember", "\354\227\254\355\226\211\354\202\254 \354\243\274 \354\267\250\352\270\211 \352\265\255\352\260\200", nullptr));
        label_9->setText(QApplication::translate("AgencyMember", "\354\227\254\355\226\211\354\202\254 \354\243\274 \354\267\250\352\270\211 \353\217\204\354\213\234(\353\230\220\353\212\224 \354\234\240\353\252\205\354\247\200\354\227\255, \352\264\200\352\264\221\353\252\205\354\206\214)", nullptr));
        pushButton->setText(QApplication::translate("AgencyMember", "\352\260\200\354\236\205", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AgencyMember: public Ui_AgencyMember {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AGENCYMEMBER_H
