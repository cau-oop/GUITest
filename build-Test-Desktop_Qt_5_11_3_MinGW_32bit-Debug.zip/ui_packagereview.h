/********************************************************************************
** Form generated from reading UI file 'packagereview.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PACKAGEREVIEW_H
#define UI_PACKAGEREVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_PackageReview
{
public:
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_2;

    void setupUi(QDialog *PackageReview)
    {
        if (PackageReview->objectName().isEmpty())
            PackageReview->setObjectName(QStringLiteral("PackageReview"));
        PackageReview->resize(640, 640);
        lineEdit = new QLineEdit(PackageReview);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(120, 240, 411, 161));
        pushButton = new QPushButton(PackageReview);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(450, 420, 75, 23));
        label = new QLabel(PackageReview);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 200, 101, 31));
        label_2 = new QLabel(PackageReview);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(190, 210, 51, 16));
        label_3 = new QLabel(PackageReview);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 160, 131, 41));
        lineEdit_2 = new QLineEdit(PackageReview);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(190, 170, 341, 20));

        retranslateUi(PackageReview);

        QMetaObject::connectSlotsByName(PackageReview);
    } // setupUi

    void retranslateUi(QDialog *PackageReview)
    {
        PackageReview->setWindowTitle(QApplication::translate("PackageReview", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("PackageReview", "\355\231\225\354\235\270", nullptr));
        label->setText(QApplication::translate("PackageReview", "\354\202\254\354\232\251\354\236\220", nullptr));
        label_2->setText(QString());
        label_3->setText(QApplication::translate("PackageReview", "\355\214\250\355\202\244\354\247\200 \353\262\210\355\230\270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PackageReview: public Ui_PackageReview {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PACKAGEREVIEW_H
