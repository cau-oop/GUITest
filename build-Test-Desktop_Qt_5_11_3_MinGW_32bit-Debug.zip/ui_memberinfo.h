/********************************************************************************
** Form generated from reading UI file 'memberinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEMBERINFO_H
#define UI_MEMBERINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_memberInfo
{
public:
    QPushButton *pushButton_6;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_7;

    void setupUi(QDialog *memberInfo)
    {
        if (memberInfo->objectName().isEmpty())
            memberInfo->setObjectName(QStringLiteral("memberInfo"));
        memberInfo->resize(640, 640);
        pushButton_6 = new QPushButton(memberInfo);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(50, 22, 75, 31));
        layoutWidget = new QWidget(memberInfo);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(190, 110, 271, 291));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(layoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(layoutWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);

        pushButton_7 = new QPushButton(memberInfo);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(290, 420, 75, 23));

        retranslateUi(memberInfo);

        QMetaObject::connectSlotsByName(memberInfo);
    } // setupUi

    void retranslateUi(QDialog *memberInfo)
    {
        memberInfo->setWindowTitle(QApplication::translate("memberInfo", "Dialog", nullptr));
        pushButton_6->setText(QApplication::translate("memberInfo", "\353\222\244\353\241\234", nullptr));
        pushButton->setText(QApplication::translate("memberInfo", "\353\271\204\353\260\200\353\262\210\355\230\270 \353\263\200\352\262\275", nullptr));
        pushButton_2->setText(QApplication::translate("memberInfo", "\354\240\204\355\231\224\353\262\210\355\230\270 \353\263\200\352\262\275", nullptr));
        pushButton_3->setText(QApplication::translate("memberInfo", "\353\251\224\354\235\274 \354\210\230\354\213\240 \353\217\231\354\235\230", nullptr));
        pushButton_4->setText(QApplication::translate("memberInfo", "\352\264\200\354\213\254 \352\265\255\352\260\200 \353\263\200\352\262\275", nullptr));
        pushButton_5->setText(QApplication::translate("memberInfo", "\352\264\200\354\213\254 \353\217\204\354\213\234 \353\263\200\352\262\275", nullptr));
        pushButton_7->setText(QApplication::translate("memberInfo", "\354\240\200\354\236\245", nullptr));
    } // retranslateUi

};

namespace Ui {
    class memberInfo: public Ui_memberInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEMBERINFO_H
