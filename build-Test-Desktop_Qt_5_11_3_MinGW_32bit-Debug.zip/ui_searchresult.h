/********************************************************************************
** Form generated from reading UI file 'searchresult.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEARCHRESULT_H
#define UI_SEARCHRESULT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_searchresult
{
public:
    QLabel *title;
    QTabWidget *tabWidget;
    QWidget *prod1;
    QWidget *prod2;
    QWidget *prod3;
    QPushButton *buy;

    void setupUi(QDialog *searchresult)
    {
        if (searchresult->objectName().isEmpty())
            searchresult->setObjectName(QStringLiteral("searchresult"));
        searchresult->resize(640, 640);
        title = new QLabel(searchresult);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(300, 20, 91, 31));
        tabWidget = new QTabWidget(searchresult);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(20, 120, 601, 431));
        prod1 = new QWidget();
        prod1->setObjectName(QStringLiteral("prod1"));
        tabWidget->addTab(prod1, QString());
        prod2 = new QWidget();
        prod2->setObjectName(QStringLiteral("prod2"));
        tabWidget->addTab(prod2, QString());
        prod3 = new QWidget();
        prod3->setObjectName(QStringLiteral("prod3"));
        tabWidget->addTab(prod3, QString());
        buy = new QPushButton(searchresult);
        buy->setObjectName(QStringLiteral("buy"));
        buy->setGeometry(QRect(220, 560, 200, 50));

        retranslateUi(searchresult);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(searchresult);
    } // setupUi

    void retranslateUi(QDialog *searchresult)
    {
        searchresult->setWindowTitle(QApplication::translate("searchresult", "Dialog", nullptr));
        title->setText(QApplication::translate("searchresult", "\352\262\200\354\203\211 \353\220\234 \352\262\260\352\263\274", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(prod1), QApplication::translate("searchresult", "Prod1", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(prod2), QApplication::translate("searchresult", "Prod2", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(prod3), QApplication::translate("searchresult", "Prod3", nullptr));
        buy->setText(QApplication::translate("searchresult", "\352\265\254\353\247\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class searchresult: public Ui_searchresult {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEARCHRESULT_H
