/********************************************************************************
** Form generated from reading UI file 'guiderank.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUIDERANK_H
#define UI_GUIDERANK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GuideRank
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLabel *label_3;
    QVBoxLayout *verticalLayout;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_5;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *GuideRank)
    {
        if (GuideRank->objectName().isEmpty())
            GuideRank->setObjectName(QStringLiteral("GuideRank"));
        GuideRank->resize(640, 640);
        layoutWidget = new QWidget(GuideRank);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(190, 140, 258, 272));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout_2->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout->addWidget(label_3);


        verticalLayout_2->addLayout(horizontalLayout);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        radioButton = new QRadioButton(layoutWidget);
        radioButton->setObjectName(QStringLiteral("radioButton"));

        verticalLayout->addWidget(radioButton);

        radioButton_2 = new QRadioButton(layoutWidget);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));

        verticalLayout->addWidget(radioButton_2);

        radioButton_3 = new QRadioButton(layoutWidget);
        radioButton_3->setObjectName(QStringLiteral("radioButton_3"));

        verticalLayout->addWidget(radioButton_3);

        radioButton_4 = new QRadioButton(layoutWidget);
        radioButton_4->setObjectName(QStringLiteral("radioButton_4"));

        verticalLayout->addWidget(radioButton_4);

        radioButton_5 = new QRadioButton(layoutWidget);
        radioButton_5->setObjectName(QStringLiteral("radioButton_5"));

        verticalLayout->addWidget(radioButton_5);


        verticalLayout_2->addLayout(verticalLayout);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout_2->addWidget(pushButton);

        pushButton_2 = new QPushButton(GuideRank);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 32, 91, 41));

        retranslateUi(GuideRank);

        QMetaObject::connectSlotsByName(GuideRank);
    } // setupUi

    void retranslateUi(QDialog *GuideRank)
    {
        GuideRank->setWindowTitle(QApplication::translate("GuideRank", "Dialog", nullptr));
        label->setText(QApplication::translate("GuideRank", "\352\260\200\354\235\264\353\223\234\353\245\274 \355\217\211\352\260\200\355\225\264\354\243\274\354\204\270\354\232\224.", nullptr));
        label_2->setText(QApplication::translate("GuideRank", "\352\260\200\354\235\264\353\223\234 \354\235\264\353\246\204 ", nullptr));
        label_3->setText(QString());
        radioButton->setText(QApplication::translate("GuideRank", "\342\230\205", nullptr));
        radioButton_2->setText(QApplication::translate("GuideRank", "\342\230\205\342\230\205", nullptr));
        radioButton_3->setText(QApplication::translate("GuideRank", "\342\230\205\342\230\205\342\230\205", nullptr));
        radioButton_4->setText(QApplication::translate("GuideRank", "\342\230\205\342\230\205\342\230\205\342\230\205", nullptr));
        radioButton_5->setText(QApplication::translate("GuideRank", "\342\230\205\342\230\205\342\230\205\342\230\205\342\230\205", nullptr));
        pushButton->setText(QApplication::translate("GuideRank", "\355\217\211\352\260\200 \354\231\204\353\243\214", nullptr));
        pushButton_2->setText(QApplication::translate("GuideRank", "\353\222\244\353\241\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GuideRank: public Ui_GuideRank {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUIDERANK_H
