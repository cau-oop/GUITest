/********************************************************************************
** Form generated from reading UI file 'loginfail2.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINFAIL2_H
#define UI_LOGINFAIL2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_LoginFail2
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *LoginFail2)
    {
        if (LoginFail2->objectName().isEmpty())
            LoginFail2->setObjectName(QStringLiteral("LoginFail2"));
        LoginFail2->resize(350, 350);
        pushButton = new QPushButton(LoginFail2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(120, 270, 75, 30));
        label = new QLabel(LoginFail2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 20, 301, 111));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setTextFormat(Qt::AutoText);
        label_2 = new QLabel(LoginFail2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 110, 231, 141));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        label_2->setFont(font1);

        retranslateUi(LoginFail2);

        QMetaObject::connectSlotsByName(LoginFail2);
    } // setupUi

    void retranslateUi(QDialog *LoginFail2)
    {
        LoginFail2->setWindowTitle(QApplication::translate("LoginFail2", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("LoginFail2", "\355\231\225\354\235\270", nullptr));
        label->setText(QApplication::translate("LoginFail2", "\353\241\234\352\267\270\354\235\270\354\227\220 \354\213\244\355\214\250\355\226\210\354\212\265\353\213\210\353\213\244.", nullptr));
        label_2->setText(QApplication::translate("LoginFail2", "<html><head/><body><p align=\"center\">\353\271\204\353\260\200\353\262\210\355\230\270\353\245\274 </p><p align=\"center\">\354\236\230\353\252\273 \354\236\205\353\240\245\355\225\230\354\205\250\354\212\265\353\213\210\353\213\244.</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginFail2: public Ui_LoginFail2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINFAIL2_H
