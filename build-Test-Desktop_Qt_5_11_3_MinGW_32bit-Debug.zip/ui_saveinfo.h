/********************************************************************************
** Form generated from reading UI file 'saveinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SAVEINFO_H
#define UI_SAVEINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_SaveInfo
{
public:

    void setupUi(QDialog *SaveInfo)
    {
        if (SaveInfo->objectName().isEmpty())
            SaveInfo->setObjectName(QStringLiteral("SaveInfo"));
        SaveInfo->resize(400, 300);

        retranslateUi(SaveInfo);

        QMetaObject::connectSlotsByName(SaveInfo);
    } // setupUi

    void retranslateUi(QDialog *SaveInfo)
    {
        SaveInfo->setWindowTitle(QApplication::translate("SaveInfo", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SaveInfo: public Ui_SaveInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAVEINFO_H
