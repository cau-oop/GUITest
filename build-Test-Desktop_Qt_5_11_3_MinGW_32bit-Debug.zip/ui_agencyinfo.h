/********************************************************************************
** Form generated from reading UI file 'agencyinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AGENCYINFO_H
#define UI_AGENCYINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AgencyInfo
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *AgencyInfo)
    {
        if (AgencyInfo->objectName().isEmpty())
            AgencyInfo->setObjectName(QStringLiteral("AgencyInfo"));
        AgencyInfo->resize(640, 640);
        pushButton = new QPushButton(AgencyInfo);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(260, 250, 101, 23));
        pushButton_2 = new QPushButton(AgencyInfo);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 60, 75, 23));

        retranslateUi(AgencyInfo);

        QMetaObject::connectSlotsByName(AgencyInfo);
    } // setupUi

    void retranslateUi(QDialog *AgencyInfo)
    {
        AgencyInfo->setWindowTitle(QApplication::translate("AgencyInfo", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("AgencyInfo", "\353\271\204\353\260\200\353\262\210\355\230\270 \353\263\200\352\262\275", nullptr));
        pushButton_2->setText(QApplication::translate("AgencyInfo", "\353\222\244\353\241\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AgencyInfo: public Ui_AgencyInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AGENCYINFO_H
