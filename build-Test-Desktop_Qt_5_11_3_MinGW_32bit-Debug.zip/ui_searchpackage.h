/********************************************************************************
** Form generated from reading UI file 'searchpackage.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEARCHPACKAGE_H
#define UI_SEARCHPACKAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_searchpackage
{
public:
    QLabel *label;
    QPushButton *searchbut;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QCheckBox *asklocation;
    QCheckBox *askminp;
    QCheckBox *askmaxp;
    QCheckBox *askdate;
    QCheckBox *askvia;
    QCheckBox *askfree;
    QCheckBox *askppl;
    QCheckBox *asktag;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *slocation;
    QLineEdit *ansloc;
    QPushButton *loc_button;
    QLabel *label_2;
    QWidget *tab_2;
    QWidget *sminprice;
    QSlider *priceslider;
    QLabel *pricelabel;
    QPushButton *loc_button_2;
    QLabel *label_3;
    QWidget *tab_3;
    QWidget *smaxprice;
    QSlider *priceslider_2;
    QLabel *pricelabel_2;
    QPushButton *loc_button_3;
    QLabel *label_4;
    QWidget *tab_4;
    QWidget *trav_start_date;
    QDateEdit *dateEdit;
    QPushButton *loc_button_4;
    QWidget *tab_5;
    QComboBox *via_combox;
    QPushButton *loc_button_5;
    QLabel *label_5;
    QWidget *tab_6;
    QComboBox *trav_combox;
    QPushButton *loc_button_6;
    QLabel *label_6;
    QWidget *tab_7;
    QWidget *ppl;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QSpinBox *adultspin;
    QSpinBox *childspin;
    QSpinBox *under;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *adult;
    QLabel *child;
    QLabel *under6;
    QPushButton *loc_button_7;
    QLabel *label_7;
    QWidget *tab_8;
    QLineEdit *tagline;
    QPushButton *loc_button_8;
    QLabel *label_8;
    QLabel *label_9;

    void setupUi(QDialog *searchpackage)
    {
        if (searchpackage->objectName().isEmpty())
            searchpackage->setObjectName(QStringLiteral("searchpackage"));
        searchpackage->resize(640, 640);
        label = new QLabel(searchpackage);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 30, 71, 21));
        searchbut = new QPushButton(searchpackage);
        searchbut->setObjectName(QStringLiteral("searchbut"));
        searchbut->setGeometry(QRect(410, 590, 161, 20));
        layoutWidget = new QWidget(searchpackage);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 100, 121, 291));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        asklocation = new QCheckBox(layoutWidget);
        asklocation->setObjectName(QStringLiteral("asklocation"));

        verticalLayout->addWidget(asklocation);

        askminp = new QCheckBox(layoutWidget);
        askminp->setObjectName(QStringLiteral("askminp"));

        verticalLayout->addWidget(askminp);

        askmaxp = new QCheckBox(layoutWidget);
        askmaxp->setObjectName(QStringLiteral("askmaxp"));

        verticalLayout->addWidget(askmaxp);

        askdate = new QCheckBox(layoutWidget);
        askdate->setObjectName(QStringLiteral("askdate"));

        verticalLayout->addWidget(askdate);

        askvia = new QCheckBox(layoutWidget);
        askvia->setObjectName(QStringLiteral("askvia"));

        verticalLayout->addWidget(askvia);

        askfree = new QCheckBox(layoutWidget);
        askfree->setObjectName(QStringLiteral("askfree"));

        verticalLayout->addWidget(askfree);

        askppl = new QCheckBox(layoutWidget);
        askppl->setObjectName(QStringLiteral("askppl"));

        verticalLayout->addWidget(askppl);

        asktag = new QCheckBox(layoutWidget);
        asktag->setObjectName(QStringLiteral("asktag"));

        verticalLayout->addWidget(asktag);

        tabWidget = new QTabWidget(searchpackage);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(170, 100, 451, 271));
        tabWidget->setTabShape(QTabWidget::Rounded);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        slocation = new QWidget(tab);
        slocation->setObjectName(QStringLiteral("slocation"));
        slocation->setGeometry(QRect(120, 100, 221, 41));
        ansloc = new QLineEdit(slocation);
        ansloc->setObjectName(QStringLiteral("ansloc"));
        ansloc->setGeometry(QRect(10, 10, 113, 20));
        loc_button = new QPushButton(slocation);
        loc_button->setObjectName(QStringLiteral("loc_button"));
        loc_button->setGeometry(QRect(130, 10, 80, 20));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(123, 50, 121, 31));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        sminprice = new QWidget(tab_2);
        sminprice->setObjectName(QStringLiteral("sminprice"));
        sminprice->setGeometry(QRect(50, 70, 371, 61));
        priceslider = new QSlider(sminprice);
        priceslider->setObjectName(QStringLiteral("priceslider"));
        priceslider->setGeometry(QRect(20, 10, 311, 16));
        priceslider->setMinimum(3);
        priceslider->setMaximum(500);
        priceslider->setOrientation(Qt::Horizontal);
        priceslider->setTickPosition(QSlider::TicksAbove);
        priceslider->setTickInterval(100);
        pricelabel = new QLabel(sminprice);
        pricelabel->setObjectName(QStringLiteral("pricelabel"));
        pricelabel->setGeometry(QRect(150, 40, 54, 16));
        loc_button_2 = new QPushButton(sminprice);
        loc_button_2->setObjectName(QStringLiteral("loc_button_2"));
        loc_button_2->setGeometry(QRect(280, 40, 80, 16));
        label_3 = new QLabel(tab_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(173, 20, 71, 21));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        smaxprice = new QWidget(tab_3);
        smaxprice->setObjectName(QStringLiteral("smaxprice"));
        smaxprice->setGeometry(QRect(30, 90, 371, 61));
        priceslider_2 = new QSlider(smaxprice);
        priceslider_2->setObjectName(QStringLiteral("priceslider_2"));
        priceslider_2->setGeometry(QRect(20, 10, 311, 16));
        priceslider_2->setMinimum(3);
        priceslider_2->setMaximum(500);
        priceslider_2->setOrientation(Qt::Horizontal);
        priceslider_2->setTickPosition(QSlider::TicksAbove);
        priceslider_2->setTickInterval(100);
        pricelabel_2 = new QLabel(smaxprice);
        pricelabel_2->setObjectName(QStringLiteral("pricelabel_2"));
        pricelabel_2->setGeometry(QRect(150, 40, 54, 16));
        loc_button_3 = new QPushButton(smaxprice);
        loc_button_3->setObjectName(QStringLiteral("loc_button_3"));
        loc_button_3->setGeometry(QRect(280, 40, 80, 16));
        label_4 = new QLabel(tab_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(180, 30, 111, 31));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        trav_start_date = new QWidget(tab_4);
        trav_start_date->setObjectName(QStringLiteral("trav_start_date"));
        trav_start_date->setGeometry(QRect(70, 20, 301, 181));
        dateEdit = new QDateEdit(trav_start_date);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(30, 20, 110, 22));
        dateEdit->setCalendarPopup(true);
        loc_button_4 = new QPushButton(trav_start_date);
        loc_button_4->setObjectName(QStringLiteral("loc_button_4"));
        loc_button_4->setGeometry(QRect(190, 150, 80, 16));
        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        via_combox = new QComboBox(tab_5);
        via_combox->setObjectName(QStringLiteral("via_combox"));
        via_combox->setGeometry(QRect(100, 130, 72, 22));
        via_combox->setMaxVisibleItems(2);
        loc_button_5 = new QPushButton(tab_5);
        loc_button_5->setObjectName(QStringLiteral("loc_button_5"));
        loc_button_5->setGeometry(QRect(240, 130, 80, 16));
        label_5 = new QLabel(tab_5);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(173, 30, 71, 21));
        tabWidget->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        trav_combox = new QComboBox(tab_6);
        trav_combox->setObjectName(QStringLiteral("trav_combox"));
        trav_combox->setGeometry(QRect(110, 120, 72, 22));
        trav_combox->setEditable(false);
        trav_combox->setMaxVisibleItems(2);
        loc_button_6 = new QPushButton(tab_6);
        loc_button_6->setObjectName(QStringLiteral("loc_button_6"));
        loc_button_6->setGeometry(QRect(240, 120, 80, 16));
        label_6 = new QLabel(tab_6);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(180, 30, 71, 31));
        tabWidget->addTab(tab_6, QString());
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        ppl = new QWidget(tab_7);
        ppl->setObjectName(QStringLiteral("ppl"));
        ppl->setGeometry(QRect(130, 50, 211, 131));
        layoutWidget1 = new QWidget(ppl);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 50, 182, 34));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        adultspin = new QSpinBox(layoutWidget1);
        adultspin->setObjectName(QStringLiteral("adultspin"));

        horizontalLayout->addWidget(adultspin);

        childspin = new QSpinBox(layoutWidget1);
        childspin->setObjectName(QStringLiteral("childspin"));

        horizontalLayout->addWidget(childspin);

        under = new QSpinBox(layoutWidget1);
        under->setObjectName(QStringLiteral("under"));

        horizontalLayout->addWidget(under);

        layoutWidget2 = new QWidget(ppl);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(10, 20, 230, 26));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        adult = new QLabel(layoutWidget2);
        adult->setObjectName(QStringLiteral("adult"));

        horizontalLayout_2->addWidget(adult);

        child = new QLabel(layoutWidget2);
        child->setObjectName(QStringLiteral("child"));

        horizontalLayout_2->addWidget(child);

        under6 = new QLabel(layoutWidget2);
        under6->setObjectName(QStringLiteral("under6"));

        horizontalLayout_2->addWidget(under6);

        loc_button_7 = new QPushButton(ppl);
        loc_button_7->setObjectName(QStringLiteral("loc_button_7"));
        loc_button_7->setGeometry(QRect(50, 90, 80, 16));
        label_7 = new QLabel(tab_7);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(190, 20, 71, 21));
        tabWidget->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        tagline = new QLineEdit(tab_8);
        tagline->setObjectName(QStringLiteral("tagline"));
        tagline->setGeometry(QRect(130, 110, 181, 20));
        loc_button_8 = new QPushButton(tab_8);
        loc_button_8->setObjectName(QStringLiteral("loc_button_8"));
        loc_button_8->setGeometry(QRect(320, 110, 80, 16));
        label_8 = new QLabel(tab_8);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(210, 40, 71, 21));
        tabWidget->addTab(tab_8, QString());
        label_9 = new QLabel(searchpackage);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(150, 400, 450, 150));

        retranslateUi(searchpackage);
        QObject::connect(loc_button, SIGNAL(clicked()), asklocation, SLOT(click()));
        QObject::connect(loc_button_8, SIGNAL(clicked()), asktag, SLOT(click()));
        QObject::connect(loc_button_7, SIGNAL(clicked()), askppl, SLOT(click()));
        QObject::connect(loc_button_6, SIGNAL(clicked()), askfree, SLOT(click()));
        QObject::connect(loc_button_5, SIGNAL(clicked()), askvia, SLOT(click()));
        QObject::connect(loc_button_4, SIGNAL(clicked()), askdate, SLOT(click()));
        QObject::connect(loc_button_3, SIGNAL(clicked()), askmaxp, SLOT(click()));
        QObject::connect(loc_button_2, SIGNAL(clicked()), askminp, SLOT(click()));

        tabWidget->setCurrentIndex(7);
        via_combox->setCurrentIndex(-1);
        trav_combox->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(searchpackage);
    } // setupUi

    void retranslateUi(QDialog *searchpackage)
    {
        searchpackage->setWindowTitle(QApplication::translate("searchpackage", "Dialog", nullptr));
        label->setText(QApplication::translate("searchpackage", "\355\214\250\355\202\244\354\247\200 \352\262\200\354\203\211", nullptr));
        searchbut->setText(QApplication::translate("searchpackage", "\352\262\200\354\203\211\355\225\230\352\270\260", nullptr));
        asklocation->setText(QApplication::translate("searchpackage", "\354\247\200\354\227\255", nullptr));
        askminp->setText(QApplication::translate("searchpackage", "\354\265\234\354\206\214\352\260\200\352\262\251", nullptr));
        askmaxp->setText(QApplication::translate("searchpackage", "\354\265\234\353\214\200\352\260\200\352\262\251", nullptr));
        askdate->setText(QApplication::translate("searchpackage", "\354\266\234\353\260\234\354\235\274", nullptr));
        askvia->setText(QApplication::translate("searchpackage", "\352\262\275\354\234\240", nullptr));
        askfree->setText(QApplication::translate("searchpackage", "\354\236\220\354\234\240\354\235\274\354\240\225", nullptr));
        askppl->setText(QApplication::translate("searchpackage", "\354\227\254\355\226\211\354\235\270\354\233\220", nullptr));
        asktag->setText(QApplication::translate("searchpackage", "\355\202\244\354\233\214\353\223\234", nullptr));
        loc_button->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_2->setText(QApplication::translate("searchpackage", "\354\234\204\354\271\230 \352\262\200\354\203\211", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("searchpackage", "location", nullptr));
        pricelabel->setText(QString());
        loc_button_2->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_3->setText(QApplication::translate("searchpackage", "\354\265\234\354\206\214\352\260\200\352\262\251", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("searchpackage", "min", nullptr));
        pricelabel_2->setText(QString());
        loc_button_3->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_4->setText(QApplication::translate("searchpackage", "\354\265\234\353\214\200\352\260\200\352\262\251", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("searchpackage", "max", nullptr));
        loc_button_4->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("searchpackage", "date", nullptr));
        via_combox->setCurrentText(QString());
        loc_button_5->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_5->setText(QApplication::translate("searchpackage", "\352\262\275\354\234\240", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("searchpackage", "via", nullptr));
        trav_combox->setCurrentText(QString());
        loc_button_6->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_6->setText(QApplication::translate("searchpackage", "\354\236\220\354\234\240 \354\227\254\355\226\211", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("searchpackage", "free", nullptr));
        adult->setText(QApplication::translate("searchpackage", "\354\204\261\354\235\270", nullptr));
        child->setText(QApplication::translate("searchpackage", "\354\206\214\354\225\204(\354\264\210,\354\244\221)", nullptr));
        under6->setText(QApplication::translate("searchpackage", "\354\234\240\354\225\204", nullptr));
        loc_button_7->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_7->setText(QApplication::translate("searchpackage", "\354\227\254\355\226\211\354\235\270\354\233\220", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_7), QApplication::translate("searchpackage", "people", nullptr));
        loc_button_8->setText(QApplication::translate("searchpackage", "\355\231\225\354\235\270", nullptr));
        label_8->setText(QApplication::translate("searchpackage", "\355\202\244\354\233\214\353\223\234", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_8), QApplication::translate("searchpackage", "keyword", nullptr));
        label_9->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class searchpackage: public Ui_searchpackage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEARCHPACKAGE_H
