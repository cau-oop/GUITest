/********************************************************************************
** Form generated from reading UI file 'newphone.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWPHONE_H
#define UI_NEWPHONE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NewPhone
{
public:
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButton;

    void setupUi(QDialog *NewPhone)
    {
        if (NewPhone->objectName().isEmpty())
            NewPhone->setObjectName(QStringLiteral("NewPhone"));
        NewPhone->resize(640, 640);
        widget = new QWidget(NewPhone);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(76, 170, 391, 25));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout->addWidget(lineEdit);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);


        retranslateUi(NewPhone);

        QMetaObject::connectSlotsByName(NewPhone);
    } // setupUi

    void retranslateUi(QDialog *NewPhone)
    {
        NewPhone->setWindowTitle(QApplication::translate("NewPhone", "Dialog", nullptr));
        label->setText(QApplication::translate("NewPhone", "\353\263\200\352\262\275\355\225\240 \354\240\204\355\231\224\353\262\210\355\230\270", nullptr));
        pushButton->setText(QApplication::translate("NewPhone", "\355\231\225\354\235\270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NewPhone: public Ui_NewPhone {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWPHONE_H
