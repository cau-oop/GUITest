/********************************************************************************
** Form generated from reading UI file 'guideinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUIDEINFO_H
#define UI_GUIDEINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_GuideInfo
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *GuideInfo)
    {
        if (GuideInfo->objectName().isEmpty())
            GuideInfo->setObjectName(QStringLiteral("GuideInfo"));
        GuideInfo->resize(640, 640);
        pushButton = new QPushButton(GuideInfo);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(290, 230, 75, 23));
        pushButton_2 = new QPushButton(GuideInfo);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 60, 75, 23));

        retranslateUi(GuideInfo);

        QMetaObject::connectSlotsByName(GuideInfo);
    } // setupUi

    void retranslateUi(QDialog *GuideInfo)
    {
        GuideInfo->setWindowTitle(QApplication::translate("GuideInfo", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("GuideInfo", "PushButton", nullptr));
        pushButton_2->setText(QApplication::translate("GuideInfo", "\353\222\244\353\241\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GuideInfo: public Ui_GuideInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUIDEINFO_H
