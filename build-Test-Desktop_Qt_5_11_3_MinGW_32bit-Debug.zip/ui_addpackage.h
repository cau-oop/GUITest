/********************************************************************************
** Form generated from reading UI file 'addpackage.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPACKAGE_H
#define UI_ADDPACKAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addPackage
{
public:
    QLabel *packagelabel;
    QWidget *packagename;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLineEdit *name_line;
    QPushButton *name_button;
    QWidget *location;
    QComboBox *loc_combo;
    QPushButton *loc_button;
    QWidget *tag;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_4;
    QLineEdit *tag_line;
    QPushButton *tag_button_2;
    QWidget *price;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *price_line;
    QPushButton *price_button_2;
    QWidget *via;
    QPushButton *via_button_2;
    QComboBox *via_combox;
    QWidget *trav_start_date;
    QDateEdit *dateEdit;
    QPushButton *date_button;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *PID;
    QLCDNumber *PID_LCD;
    QPushButton *pname_button;
    QPushButton *location_button;
    QPushButton *tag_button;
    QPushButton *price_button;
    QPushButton *via_button;
    QPushButton *trav_date_button;
    QPushButton *trav_hour_button;
    QPushButton *how_long_button_2;
    QPushButton *trav_free_button;
    QPushButton *minppl_button;
    QPushButton *maxppl_button;
    QWidget *trav_start_hour;
    QPushButton *start_button;
    QTimeEdit *timeEdit;
    QWidget *free_trav;
    QPushButton *trav_button;
    QComboBox *trav_combo;
    QWidget *how_long_trav;
    QLineEdit *how_long_line;
    QPushButton *how_long_button;
    QWidget *minppl;
    QSpinBox *min_spin;
    QPushButton *min_button;
    QWidget *maxppl;
    QSpinBox *max_spinbox;
    QPushButton *max_button;
    QPushButton *finish;

    void setupUi(QDialog *addPackage)
    {
        if (addPackage->objectName().isEmpty())
            addPackage->setObjectName(QStringLiteral("addPackage"));
        addPackage->resize(640, 640);
        packagelabel = new QLabel(addPackage);
        packagelabel->setObjectName(QStringLiteral("packagelabel"));
        packagelabel->setGeometry(QRect(40, 20, 81, 31));
        packagename = new QWidget(addPackage);
        packagename->setObjectName(QStringLiteral("packagename"));
        packagename->setEnabled(true);
        packagename->setGeometry(QRect(290, 40, 211, 41));
        layoutWidget = new QWidget(packagename);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 196, 25));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        name_line = new QLineEdit(layoutWidget);
        name_line->setObjectName(QStringLiteral("name_line"));

        horizontalLayout->addWidget(name_line);

        name_button = new QPushButton(layoutWidget);
        name_button->setObjectName(QStringLiteral("name_button"));

        horizontalLayout->addWidget(name_button);

        location = new QWidget(addPackage);
        location->setObjectName(QStringLiteral("location"));
        location->setGeometry(QRect(300, 90, 311, 41));
        loc_combo = new QComboBox(location);
        loc_combo->setObjectName(QStringLiteral("loc_combo"));
        loc_combo->setGeometry(QRect(0, 10, 201, 22));
        loc_button = new QPushButton(location);
        loc_button->setObjectName(QStringLiteral("loc_button"));
        loc_button->setGeometry(QRect(210, 10, 80, 20));
        tag = new QWidget(addPackage);
        tag->setObjectName(QStringLiteral("tag"));
        tag->setEnabled(true);
        tag->setGeometry(QRect(290, 130, 311, 41));
        layoutWidget_3 = new QWidget(tag);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(10, 10, 196, 24));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        tag_line = new QLineEdit(layoutWidget_3);
        tag_line->setObjectName(QStringLiteral("tag_line"));

        horizontalLayout_4->addWidget(tag_line);

        tag_button_2 = new QPushButton(tag);
        tag_button_2->setObjectName(QStringLiteral("tag_button_2"));
        tag_button_2->setGeometry(QRect(220, 10, 80, 20));
        price = new QWidget(addPackage);
        price->setObjectName(QStringLiteral("price"));
        price->setEnabled(true);
        price->setGeometry(QRect(290, 180, 211, 41));
        layoutWidget_4 = new QWidget(price);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(10, 10, 196, 25));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget_4);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        price_line = new QLineEdit(layoutWidget_4);
        price_line->setObjectName(QStringLiteral("price_line"));

        horizontalLayout_5->addWidget(price_line);

        price_button_2 = new QPushButton(layoutWidget_4);
        price_button_2->setObjectName(QStringLiteral("price_button_2"));

        horizontalLayout_5->addWidget(price_button_2);

        via = new QWidget(addPackage);
        via->setObjectName(QStringLiteral("via"));
        via->setGeometry(QRect(300, 220, 191, 41));
        via_button_2 = new QPushButton(via);
        via_button_2->setObjectName(QStringLiteral("via_button_2"));
        via_button_2->setGeometry(QRect(80, 10, 80, 20));
        via_combox = new QComboBox(via);
        via_combox->setObjectName(QStringLiteral("via_combox"));
        via_combox->setGeometry(QRect(0, 10, 72, 22));
        via_combox->setMaxVisibleItems(2);
        trav_start_date = new QWidget(addPackage);
        trav_start_date->setObjectName(QStringLiteral("trav_start_date"));
        trav_start_date->setGeometry(QRect(280, 270, 301, 71));
        dateEdit = new QDateEdit(trav_start_date);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(20, 20, 110, 22));
        dateEdit->setCalendarPopup(true);
        date_button = new QPushButton(trav_start_date);
        date_button->setObjectName(QStringLiteral("date_button"));
        date_button->setGeometry(QRect(160, 20, 80, 20));
        layoutWidget1 = new QWidget(addPackage);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(30, 70, 111, 391));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        PID = new QLabel(layoutWidget1);
        PID->setObjectName(QStringLiteral("PID"));

        verticalLayout_2->addWidget(PID);

        PID_LCD = new QLCDNumber(layoutWidget1);
        PID_LCD->setObjectName(QStringLiteral("PID_LCD"));
        PID_LCD->setProperty("intValue", QVariant(0));

        verticalLayout_2->addWidget(PID_LCD);

        pname_button = new QPushButton(layoutWidget1);
        pname_button->setObjectName(QStringLiteral("pname_button"));

        verticalLayout_2->addWidget(pname_button);

        location_button = new QPushButton(layoutWidget1);
        location_button->setObjectName(QStringLiteral("location_button"));

        verticalLayout_2->addWidget(location_button);

        tag_button = new QPushButton(layoutWidget1);
        tag_button->setObjectName(QStringLiteral("tag_button"));

        verticalLayout_2->addWidget(tag_button);

        price_button = new QPushButton(layoutWidget1);
        price_button->setObjectName(QStringLiteral("price_button"));

        verticalLayout_2->addWidget(price_button);

        via_button = new QPushButton(layoutWidget1);
        via_button->setObjectName(QStringLiteral("via_button"));

        verticalLayout_2->addWidget(via_button);

        trav_date_button = new QPushButton(layoutWidget1);
        trav_date_button->setObjectName(QStringLiteral("trav_date_button"));

        verticalLayout_2->addWidget(trav_date_button);

        trav_hour_button = new QPushButton(layoutWidget1);
        trav_hour_button->setObjectName(QStringLiteral("trav_hour_button"));

        verticalLayout_2->addWidget(trav_hour_button);

        how_long_button_2 = new QPushButton(layoutWidget1);
        how_long_button_2->setObjectName(QStringLiteral("how_long_button_2"));

        verticalLayout_2->addWidget(how_long_button_2);

        trav_free_button = new QPushButton(layoutWidget1);
        trav_free_button->setObjectName(QStringLiteral("trav_free_button"));

        verticalLayout_2->addWidget(trav_free_button);

        minppl_button = new QPushButton(layoutWidget1);
        minppl_button->setObjectName(QStringLiteral("minppl_button"));

        verticalLayout_2->addWidget(minppl_button);

        maxppl_button = new QPushButton(layoutWidget1);
        maxppl_button->setObjectName(QStringLiteral("maxppl_button"));

        verticalLayout_2->addWidget(maxppl_button);

        trav_start_hour = new QWidget(addPackage);
        trav_start_hour->setObjectName(QStringLiteral("trav_start_hour"));
        trav_start_hour->setGeometry(QRect(290, 340, 241, 41));
        start_button = new QPushButton(trav_start_hour);
        start_button->setObjectName(QStringLiteral("start_button"));
        start_button->setGeometry(QRect(140, 10, 80, 20));
        timeEdit = new QTimeEdit(trav_start_hour);
        timeEdit->setObjectName(QStringLiteral("timeEdit"));
        timeEdit->setGeometry(QRect(10, 10, 118, 22));
        timeEdit->setProperty("showGroupSeparator", QVariant(false));
        timeEdit->setCurrentSection(QDateTimeEdit::HourSection);
        free_trav = new QWidget(addPackage);
        free_trav->setObjectName(QStringLiteral("free_trav"));
        free_trav->setGeometry(QRect(300, 440, 191, 41));
        trav_button = new QPushButton(free_trav);
        trav_button->setObjectName(QStringLiteral("trav_button"));
        trav_button->setGeometry(QRect(80, 10, 80, 20));
        trav_combo = new QComboBox(free_trav);
        trav_combo->setObjectName(QStringLiteral("trav_combo"));
        trav_combo->setGeometry(QRect(0, 10, 72, 22));
        trav_combo->setEditable(false);
        trav_combo->setMaxVisibleItems(2);
        how_long_trav = new QWidget(addPackage);
        how_long_trav->setObjectName(QStringLiteral("how_long_trav"));
        how_long_trav->setGeometry(QRect(290, 390, 131, 41));
        how_long_line = new QLineEdit(how_long_trav);
        how_long_line->setObjectName(QStringLiteral("how_long_line"));
        how_long_line->setGeometry(QRect(10, 10, 51, 20));
        how_long_button = new QPushButton(how_long_trav);
        how_long_button->setObjectName(QStringLiteral("how_long_button"));
        how_long_button->setGeometry(QRect(70, 10, 51, 20));
        minppl = new QWidget(addPackage);
        minppl->setObjectName(QStringLiteral("minppl"));
        minppl->setGeometry(QRect(280, 490, 131, 41));
        min_spin = new QSpinBox(minppl);
        min_spin->setObjectName(QStringLiteral("min_spin"));
        min_spin->setGeometry(QRect(20, 10, 46, 22));
        min_button = new QPushButton(minppl);
        min_button->setObjectName(QStringLiteral("min_button"));
        min_button->setGeometry(QRect(70, 10, 51, 20));
        maxppl = new QWidget(addPackage);
        maxppl->setObjectName(QStringLiteral("maxppl"));
        maxppl->setGeometry(QRect(430, 490, 131, 41));
        max_spinbox = new QSpinBox(maxppl);
        max_spinbox->setObjectName(QStringLiteral("max_spinbox"));
        max_spinbox->setGeometry(QRect(20, 10, 46, 22));
        max_button = new QPushButton(maxppl);
        max_button->setObjectName(QStringLiteral("max_button"));
        max_button->setGeometry(QRect(70, 10, 51, 20));
        finish = new QPushButton(addPackage);
        finish->setObjectName(QStringLiteral("finish"));
        finish->setGeometry(QRect(70, 510, 111, 71));

        retranslateUi(addPackage);
        QObject::connect(location_button, SIGNAL(clicked()), location, SLOT(show()));
        QObject::connect(loc_button, SIGNAL(clicked()), location, SLOT(hide()));
        QObject::connect(tag_button, SIGNAL(clicked()), tag, SLOT(show()));
        QObject::connect(tag_button_2, SIGNAL(clicked()), tag, SLOT(hide()));
        QObject::connect(price_button, SIGNAL(clicked()), price, SLOT(show()));
        QObject::connect(price_button_2, SIGNAL(clicked()), price, SLOT(hide()));
        QObject::connect(via_button, SIGNAL(clicked()), via, SLOT(show()));
        QObject::connect(via_button_2, SIGNAL(clicked()), via, SLOT(show()));
        QObject::connect(trav_date_button, SIGNAL(clicked()), trav_start_date, SLOT(show()));
        QObject::connect(trav_hour_button, SIGNAL(clicked()), trav_start_hour, SLOT(show()));
        QObject::connect(start_button, SIGNAL(clicked()), trav_start_hour, SLOT(hide()));
        QObject::connect(trav_free_button, SIGNAL(clicked()), free_trav, SLOT(show()));
        QObject::connect(trav_button, SIGNAL(clicked()), free_trav, SLOT(hide()));
        QObject::connect(how_long_button_2, SIGNAL(clicked()), how_long_trav, SLOT(show()));
        QObject::connect(how_long_button, SIGNAL(clicked()), how_long_trav, SLOT(hide()));
        QObject::connect(minppl_button, SIGNAL(clicked()), minppl, SLOT(show()));
        QObject::connect(min_button, SIGNAL(clicked()), minppl, SLOT(hide()));
        QObject::connect(maxppl_button, SIGNAL(clicked()), maxppl, SLOT(show()));
        QObject::connect(max_button, SIGNAL(clicked()), maxppl, SLOT(hide()));
        QObject::connect(date_button, SIGNAL(clicked()), trav_start_date, SLOT(hide()));
        QObject::connect(pname_button, SIGNAL(clicked()), packagename, SLOT(show()));
        QObject::connect(name_button, SIGNAL(clicked()), packagename, SLOT(close()));
        QObject::connect(via_button_2, SIGNAL(clicked()), via, SLOT(close()));
        QObject::connect(finish, SIGNAL(clicked()), addPackage, SLOT(close()));

        via_combox->setCurrentIndex(-1);
        trav_combo->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(addPackage);
    } // setupUi

    void retranslateUi(QDialog *addPackage)
    {
        addPackage->setWindowTitle(QApplication::translate("addPackage", "Dialog", nullptr));
        packagelabel->setText(QApplication::translate("addPackage", "Package \354\266\224\352\260\200", nullptr));
        name_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        loc_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        tag_button_2->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        price_button_2->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        via_button_2->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        via_combox->setCurrentText(QString());
        date_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        PID->setText(QApplication::translate("addPackage", "PID :", nullptr));
        pname_button->setText(QApplication::translate("addPackage", "\355\214\250\355\202\244\354\247\200 \354\235\264\353\246\204", nullptr));
        location_button->setText(QApplication::translate("addPackage", "\354\247\200\354\227\255", nullptr));
        tag_button->setText(QApplication::translate("addPackage", "\355\203\234\352\267\270", nullptr));
        price_button->setText(QApplication::translate("addPackage", "\352\260\200\352\262\251(\354\233\220\355\231\224)", nullptr));
        via_button->setText(QApplication::translate("addPackage", "\352\262\275\354\234\240", nullptr));
        trav_date_button->setText(QApplication::translate("addPackage", "\354\227\254\355\226\211 \354\266\234\353\260\234\354\235\274", nullptr));
        trav_hour_button->setText(QApplication::translate("addPackage", "\354\227\254\355\226\211 \354\266\234\353\260\234 \354\213\234\352\260\204", nullptr));
        how_long_button_2->setText(QApplication::translate("addPackage", "\354\227\254\355\226\211\352\270\260\352\260\204", nullptr));
        trav_free_button->setText(QApplication::translate("addPackage", "\354\236\220\354\234\240\354\227\254\355\226\211", nullptr));
        minppl_button->setText(QApplication::translate("addPackage", "\354\265\234\354\206\214\354\235\270\354\233\220", nullptr));
        maxppl_button->setText(QApplication::translate("addPackage", "\354\265\234\353\214\200\354\235\270\354\233\220", nullptr));
        start_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        timeEdit->setDisplayFormat(QApplication::translate("addPackage", "h:mm", nullptr));
        trav_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        trav_combo->setCurrentText(QString());
        how_long_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        min_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        max_button->setText(QApplication::translate("addPackage", "\355\231\225\354\235\270", nullptr));
        finish->setText(QApplication::translate("addPackage", "\353\223\261\353\241\235", nullptr));
    } // retranslateUi

};

namespace Ui {
    class addPackage: public Ui_addPackage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPACKAGE_H
